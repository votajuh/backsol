from app import db
from modelo.censosolar import CensoSolar

class Sitio(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100))
    ubicacion = db.Column(db.String(255))
    estado = db.Column(db.Boolean, default=True)
    external_id = db.Column(db.String(100))
    promedio = db.Column(db.Double, default=0.0)
    irradiacion = db.Column(db.Double, default=0.0)
    #coef_reflexion = db.Column(db.Double, default=0.2)
    longitud = db.Column(db.Double, default=0.0)
    latitud = db.Column(db.Double, default=0.0)
    id_canton = db.Column(db.Integer, db.ForeignKey('canton.id'),nullable=True)

    censosolar = db.relationship('CensoSolar', backref='sitio', lazy=True)
    
    def __init__(self, nombre, estado, external_id, promedio, irradiacion):
        self.nombre = nombre
        self.estado = estado
        self.promedio = promedio
        self.irradiacion = irradiacion
        self.external_id = external_id 
    
    @property
    def serialize_id(self):
       """Return object data in easily serializable format"""
       
       return {
           'external'         : self.external_id,
           'nombre':self.nombre,
           'estado' : self.estado,
           'canton' : self.id_canton,
           'irradiacion' : self.irradiacion,
           'promedio' : self.promedio,
           #'coef_reflexion' : self.coef_reflexion,
           'longitud' : self.longitud,
           'latitud' : self.latitud
           
           #'modified_at': dump_datetime(self.modified_at),
           # This is an example how to deal with Many2Many relations
           #'many2many'  : self.serialize_many2many
       }
    