from flask import Blueprint
from modelo.provincia import Provincia
from modelo.canton import Canton
from modelo.sitio import Sitio
from flask import jsonify, json, make_response, request
from util.calculos import Calculos
from decimal import Decimal
from flask_cors import CORS
api = Blueprint('api', __name__)


CORS(api)
cors = CORS(api, resource={
    r"/*":{
        "origins":"*"
    }
})
@api.route('/')
def home():
    return 'Hola api solar'
#provincias
@api.route('/api/provincia')
def lista_provincias():
    provincias = Provincia.query.all()
    return make_response(
                jsonify(
                    {"message": "OK", "code": 200, "datos":([i.serialize for i in provincias])}
                ),
                200,
            )
    #return jsonify(provincias=[i.serialize for i in provincias])


#cantones
@api.route('/api/canton')
def lista_cantones():
    cantones = Canton.query.all()
    return make_response(
                jsonify(
                    {"message": "OK", "code": 200, "datos":([i.serialize_id for i in cantones])}
                ),
                200,
            )

@api.route('/api/canton/<provinciaE>')
def lista_cantones_provincia(provinciaE):
    prov = Provincia.query.filter_by(external_id=provinciaE).first()
    if(prov):

        cantones = Canton.query.filter_by(id_provincia=prov.id).all()
        return make_response(
                jsonify(
                    {"message": "OK", "code": 200, "datos":([i.serialize_id for i in cantones])}
                ),
                200,
            )
    else:
       return make_response(
                jsonify(
                    {"message": "Error la provincia no existe", "code": 200, "datos":[]}
                ),
                200,
            ) 
    #return jsonify(cantones=[i.serialize_id for i in cantones])


#sitios
@api.route('/api/sitio')
def lista_sitios():
    sitios = Sitio.query.all()
    #return jsonify(sitios=[i.serialize_id for i in sitios])
    return make_response(
                jsonify(
                    {"message": "OK", "code": 200, "datos":([i.serialize_id for i in sitios])}
                ),
                200,
            )

@api.route('/api/sitio/canton/<externalC>')
def lista_sitios_canton(externalC):
    canton = Canton.query.filter_by(external_id=externalC).first()
    if(canton):

        sitios = Sitio.query.filter_by(id_canton=canton.id).all()
        #return jsonify(sitios=[i.serialize_id for i in sitios])
        return make_response(
                    jsonify(
                        {"message": "OK", "code": 200, "datos":([i.serialize_id for i in sitios])}
                    ),
                    200,
        )
    else:
        return make_response(
                jsonify(
                    {"message": "Error, el canton no existe", "code": 200, "datos":[]}
                ),
                200,
            )


@api.route('/api/sitio/obtener/<external>')
def obtener_sitio(external):
    sitio = Sitio.query.filter_by(external_id=external).first()
    objCalc = Calculos()
    calculos = objCalc.calculos_datos(sitio.latitud, sitio.coef_reflexion, sitio.inclinacion, sitio.orientacion)
    
    return make_response(
                jsonify(
                    {"message": "OK", "code": 200, "datos":calculos}
                ),
                200,
            )
#<coef_reflexion>/<inclinacion>/<orientacion>/<external>/<potencia>/<eficiencia>/<fs>/<rendimiento>
@api.route('/api/calculos', methods =['POST'])
def calcular_post():
    data = request.json
    coef_reflexion = data.get('coef_reflexion')
    inclinacion = data.get('inclinacion')
    orientacion = data.get('orientacion')
    external = data.get('external')
    potencia = data.get('potencia')
    eficiencia = data.get('eficiencia')
    fs = data.get('fs')
    rendimiento = data.get('rendimiento')
    objCalc = Calculos()
    sitio = Sitio.query.filter_by(external_id=external).first()
    if(sitio):
        #print (sitio)
        calculos = objCalc.calculos_datos(sitio.latitud, float(coef_reflexion), float(inclinacion), float(orientacion), sitio, float(potencia), float(eficiencia), float(fs), float(rendimiento))    
        #return jsonify(calculos)
        return make_response(
                jsonify(
                    {"message": "OK", "code": 200, "datos":calculos}
                ),
                200,
            )
    else:
        return make_response(
                jsonify(
                    {"message": "No se encuentra el sitio", "code": 403}
                ),
                403,
            )
    
@api.route('/api/calculos/<coef_reflexion>/<inclinacion>/<orientacion>/<external>/<potencia>/<eficiencia>/<fs>/<rendimiento>')
def calcular(coef_reflexion, inclinacion, orientacion, external, potencia, eficiencia, fs, rendimiento):
    objCalc = Calculos()
    sitio = Sitio.query.filter_by(external_id=external).first()
    if(sitio):
        #print (sitio)
        calculos = objCalc.calculos_datos(sitio.latitud, float(coef_reflexion), float(inclinacion), float(orientacion), sitio, float(potencia), float(eficiencia), float(fs), float(rendimiento))    
        #return jsonify(calculos)
        return make_response(
                jsonify(
                    {"message": "OK", "code": 200, "datos":calculos}
                ),
                200,
            )
    else:
        return make_response(
                jsonify(
                    {"message": "No se encuentra el sitio", "code": 403}
                ),
                403,
            )