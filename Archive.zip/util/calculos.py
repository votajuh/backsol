import math
import numpy
from decimal import Decimal

from modelo.censosolar import CensoSolar
class Calculos:
    def calculos_datos(self, latitud, coef, inclinacion, orientacion, sitio, potencia, eficiencia, fs, rendimiento):
        censo_solar = CensoSolar.query.filter_by(id_sitio=sitio.id).all()
        #print('jola')
        meses = 12
        calculo_meses = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        columnas = 15
        dias = [17, 46, 75, 105, 135, 161, 198, 228, 258, 289, 319, 345]
        sumas_meses = 0.0
        #calculo = self.crear_matriz(meses, columnas)
        calculo = []
        if(censo_solar):
            calulos_datos = []
            for i in range(meses):
            #for i in censo_solar:
                datos = []    
                #print(dias[i])
                
                dia = dias[i]
                mes1 = {"mes":(i+1)}
                datos.append(mes1)
                #datos.append((i+1))
                datos.append({"dia":dia})
                #=1+0,033*COS(RADIANES(360/365*B13))
                eps = 1+0.033*math.cos(math.radians(360/365*dia))
                datos.append({"eps":eps})            
                #=23,45*SENO(RADIANES(360/365*(B13+284)))
                declinacion = 23.45*math.sin(math.radians(360/365 * (dia+284)))
                datos.append({"declinacion":declinacion})
                #=TAN(RADIANES($D13))*TAN(RADIANES(B$7))
                none = math.tan(math.radians(declinacion)) * math.tan(math.radians(latitud))
                datos.append({"none":none})
                #=90-ABS($B$7)+D13*SIGNO($B$7)                   
                w0 =90 - abs(latitud) + (declinacion*numpy.sign(latitud))
                datos.append({"w0":w0})
                #=D13*SIGNO($B$7)-(90-ABS($B$7))
                w180 = declinacion*numpy.sign(latitud) - (90 - abs(latitud))
                datos.append({"w180":w180})
                #=SI(E13>=1;-PI();SI(E13<-1;0;-ACOS(-E13)))
                
                wsrad = 0.0
                if none >= 1.0:
                    wsrad = -math.pi                
                else:
                    if none < -1.0 :
                        wsrad = 0.0
                    else:
                        wsrad = -math.acos(-none)
                
                datos.append({"wsard":wsrad})
                
                #=H13*180/PI()
                ws0 = wsrad*180/math.pi
                datos.append({"ws0":ws0})
                #BODM
                #=SI(E13>1;(24*1367/PI())*$C13*SENO(RADIANES(D13))*SENO(RADIANES(B$7))*PI();(24*1367/PI())*$C13*COS(RADIANES(D13))*COS(RADIANES(B$7))*(H13*COS(H13)-SENO(H13)))
                bodm = 0.0
                if none > 1:
                    bodm = (24*1367/math.pi)*eps*math.sin(math.radians(declinacion))*math.sin(math.radians(latitud))*math.pi
                else:
                    bodm = (24*1367/math.pi)*eps*math.cos(math.radians(declinacion))*math.cos(math.radians(latitud))*(wsrad*math.cos(wsrad) - math.sin(wsrad))
                datos.append({"bodm":bodm})
                #GDM(0)  = mes_censo_solar * 1000  
                censo_solar_obj = censo_solar[i] 
                gdm = (censo_solar_obj.irradiacion) * 1000.00
                datos.append({"gdm":gdm})
                #KTM  
                # if (Bodm - GDM) > 0 --> GDM/Bodm else 0
                ktm = 0.0
                if((bodm - gdm) > 0):
                    ktm = gdm/bodm
                datos.append({"ktm":ktm})
                #KDM
                # if (KTM != 0 ) --> 1-1.13*KTM --> 0
                kdm = 0.0
                if(ktm != 0):
                    kdm = 1-1.13*ktm
                datos.append({"kdm":kdm})
                #DDM(0)
                ddm = kdm*gdm
                datos.append({"ddm":ddm})
                #BDM(0)
                bdm0 = gdm - ddm
                datos.append({"bdm0":bdm0})
                
                #BDM(A,B)
                #se calcula en otra tabla
                #print('*** ', coef)
                ghm_PE = self.ghm_PE(latitud, coef, inclinacion, orientacion, eps, declinacion, wsrad,ddm, gdm)
                datos.append({"ghm_PE":ghm_PE})
                #resultado = {"sumD0":sumD0, "sumG0":sumG0, "sumBa_b":sumBa_b, "sumaDab":sumaDab, "sumaRab":sumaRab, "sumaGab":sumaGab, "sumaTotal":sumaTotal}
                #Bdm(a,b)
                bdmab = ghm_PE.get("sumBa_b") 
                datos.append({"bdmab":bdmab})
                #Ddm(a,b)
                ddmab = ghm_PE.get("sumaDab")
                datos.append({"ddmab":ddmab})
                #Rdm(a,b)
                rdmab = ghm_PE.get("sumaRab")
                datos.append({"rdmab":rdmab})
                #Irradiación diaria promedio mensual Gdm(a,b), sirve para sacar los meses
                idpmgdm = bdmab+ddmab+rdmab
                datos.append({"idpmgdm":idpmgdm})
                calculo_meses[i] = {"mes":(i+1),"valor":idpmgdm}
                if(i == 1):
                    sumas_meses += idpmgdm*28
                    #print('mes 28',i)
                elif(i == 0 or i == 2 or i == 4 or i == 6 or i == 7 or i == 9 or i == 11):
                    sumas_meses += idpmgdm*31
                    #print('mes 31',i)
                #elif(i == 3 | i == 5 | i == 8 | i == 10):
                else:
                    #print('mes 30',i)
                    sumas_meses += idpmgdm*30
                #bdm_ab = 
                #print(datos)
                calulos_datos.append(datos)
            calculo.append({"calculos":calulos_datos})
            irradiacion_anual = sumas_meses / 1000.0
        calculo.append({"meses_calculados":calculo_meses})
        calculo.append({"irradiacion_anual":irradiacion_anual})
        calculo.append({"promedio_anual":1000.0*irradiacion_anual/365})
        energia_util_estimada = irradiacion_anual*potencia*(1-fs)*rendimiento
        calculo.append({"energia_util_estimada":energia_util_estimada})
        superficie = energia_util_estimada/(irradiacion_anual*(eficiencia/100))
        calculo.append({"superficie":superficie})
            #potencia, eficiencia, fs, rendimiento

        return calculo
            
        

        #calculo.append(censo_solar[0])
        #print('hola 2')
        #for i in range(len(dias)):
        
    def ghm_PE(self, latitud, coef, inclinacion, orientacion, esp0, declinacion, wsrad, ddm, gdm):
        #print('***----*** ', coef)
        perez = {"einf":[1.00,1.056,1.253,1.586,2.134,3.230,5.980,10.080],"k31":[-0.011, -0.038, 0.166, 0.419, 0.710, 0.857, 0.734, 0.421], "k32":[0.748, 1.115, 0.909, 0.646, 0.025, -0.370, -0.073, -0.661], "k33":[-0.080, -0.109, -0.179, -0.262, -0.290, -0.279, -0.228, 0.097], "k41":[-0.048, -0.023, 0.062, 0.140, 0.243, 0.267, 0.231, 0.119], "k42":[0.073, 0.106, -0.021, -0.167, -0.511, -0.792, -1.180, -2.125], "k43":[-0.024, -0.037, -0.050, -0.042, -0.004, 0.076, 0.199, 0.446]}
        #print(perez)
        latitudR = math.radians(latitud)        
        inclinacionR = math.radians(inclinacion)
        #print('inclinacion',inclinacionR)
        orientacionR = math.radians(orientacion)
        wsrad_g = wsrad*180/math.pi
        horas = wsrad_g/15
        a = 0.409-0.5016*math.sin(wsrad+math.pi/3)
        b = 0.6609+0.4767*math.sin(wsrad+math.pi/3)
        #print('a',b)
        wh = [-11.5, -10.5, -9.5, -8.5, -7.5, -6.5, -5.5, -4.5, -3.5, -2.5, -1.5, 0.5, 0.5, 1.5, 2.5, 3.5, 4.5, 5.5, 6.5, 7.5, 8.5, 9.5, 10.5, 11.5]
        #print('len',len(wh))
        sumD0 = 0.0
        sumG0 = 0.0
        sumBa_b = 0.0
        sumaDab = 0.0
        sumaRab = 0.0
        sumaGab = 0.0
        sumaTotal = 0.0
        for i in range(len(wh)):
            #wrad
            wrad = wh[i]*math.pi/12
            #rd
            rd = 0.0
            if(wsrad != 0.0):
                rd = (math.pi/24)*(math.cos(wrad) - math.cos(wsrad)) / (wsrad * math.cos(wsrad) - math.sin(wsrad))
            #d(0)
            d0 = 0.0
            if(rd > 0.0):
                d0 = ddm*rd
            sumD0 += d0
            #rg
            rg = rd*(a+b*math.cos(wrad))
            
            #G0
            g0 = 0.0
            if(rd > 0):
                g0 = gdm*rg
            sumG0 += g0

            #B(0)
            b0 = 0.0
            if(g0 > 0):
                b0 = g0 - d0

            #cos(qZs)
            qZs = math.sin(math.radians(declinacion)) * math.sin(latitudR) + math.cos(math.radians(declinacion)) * math.cos(latitudR) * math.cos(wrad)          
            #qZsRad
            qZsRad = math.acos(qZs)
            #cos(qS)
            cosqs = math.sin(math.radians(declinacion))*math.sin(latitudR)*math.cos(inclinacionR) - math.sin(math.radians(declinacion))*math.cos(latitudR)*math.sin(inclinacionR)*math.cos(orientacionR) + math.cos(math.radians(declinacion))*math.cos(latitudR)*math.cos(inclinacionR)*math.cos(wrad) + math.cos(math.radians(declinacion))*math.sin(latitudR)*math.sin(inclinacionR)*math.cos(orientacionR)*math.cos(wrad) + math.cos(math.radians(declinacion))*math.sin(orientacionR)*math.sin(wrad)*math.sin(inclinacionR)
            
            #qsrad
            qsrad = math.acos(cosqs)
            
            #B(a,b)
            #a if a > b else b
            maxi = max(0.0, cosqs)#0.0 if 0.0 > cosqs else cosqs
            #if(0.0 > cosqs):
            #    max = 0.0
            #else:
            #    max = cosqs 
            bab = (b0/qZs)*maxi
            sumBa_b += bab
            #------------
            #Epsilon
            epsilon = 0.0
            if(d0 != 0):
                epsilon = 1+b0/(d0*qZs)
            
            #AM
            am = 1/qZs

            #delta
            delta = d0*am/1367
            #k31
            k31 = 0.0
            if(epsilon == 0):
                k31 = 0.0
            elif((epsilon >= perez.get("einf")[0]) & (epsilon >= perez.get("einf")[1])):
                k31 = perez.get("k31")[0]
                if((epsilon >= perez.get("einf")[1]) & (epsilon >= perez.get("einf")[2])):
                    k31 = perez.get("k31")[1]
                    if((epsilon >= perez.get("einf")[2]) & (epsilon >= perez.get("einf")[3])):
                        k31 = perez.get("k31")[3]
                        if((epsilon >= perez.get("einf")[3]) & (epsilon >= perez.get("einf")[4])):
                            k31 = perez.get("k31")[4]
                            if((epsilon >= perez.get("einf")[4]) & (epsilon >= perez.get("einf")[5])):
                                k31 = perez.get("k31")[5]
                                if((epsilon >= perez.get("einf")[5]) & (epsilon >= perez.get("einf")[6])):
                                    k31 = perez.get("k31")[6]
                                    if(epsilon>=perez.get("einf")[6]):
                                        k31 = perez.get("k31")[7]
            
            #k32
            k32 = 0.0
            if(epsilon == 0):
                k32 = 0.0
            elif((epsilon >= perez.get("einf")[0]) & (epsilon >= perez.get("einf")[1])):
                k32 = perez.get("k32")[0]
                if((epsilon >= perez.get("einf")[1]) & (epsilon >= perez.get("einf")[2])):
                    k32 = perez.get("k32")[1]
                    if((epsilon >= perez.get("einf")[2]) & (epsilon >= perez.get("einf")[3])):
                        k32 = perez.get("k32")[3]
                        if((epsilon >= perez.get("einf")[3]) & (epsilon >= perez.get("einf")[4])):
                            k32 = perez.get("k32")[4]
                            if((epsilon >= perez.get("einf")[4]) & (epsilon >= perez.get("einf")[5])):
                                k32 = perez.get("k32")[5]
                                if((epsilon >= perez.get("einf")[5]) & (epsilon >= perez.get("einf")[6])):
                                    k32 = perez.get("k32")[6]
                                    if(epsilon>=perez.get("einf")[6]):
                                        k32 = perez.get("k32")[7]
            
            #k33
            k33 = 0.0
            if(epsilon == 0):
                k33 = 0.0
            elif((epsilon >= perez.get("einf")[0]) & (epsilon >= perez.get("einf")[1])):
                k33 = perez.get("k33")[0]
                if((epsilon >= perez.get("einf")[1]) & (epsilon >= perez.get("einf")[2])):
                    k33 = perez.get("k33")[1]
                    if((epsilon >= perez.get("einf")[2]) & (epsilon >= perez.get("einf")[3])):
                        k33 = perez.get("k33")[3]
                        if((epsilon >= perez.get("einf")[3]) & (epsilon >= perez.get("einf")[4])):
                            k33 = perez.get("k33")[4]
                            if((epsilon >= perez.get("einf")[4]) & (epsilon >= perez.get("einf")[5])):
                                k33 = perez.get("k33")[5]
                                if((epsilon >= perez.get("einf")[5]) & (epsilon >= perez.get("einf")[6])):
                                    k33 = perez.get("k33")[6]
                                    if(epsilon>=perez.get("einf")[6]):
                                        k33 = perez.get("k33")[7]
            
            #k41
            k41 = 0.0
            if(epsilon == 0):
                k41 = 0.0
            elif((epsilon >= perez.get("einf")[0]) & (epsilon >= perez.get("einf")[1])):
                k41 = perez.get("k41")[0]
                if((epsilon >= perez.get("einf")[1]) & (epsilon >= perez.get("einf")[2])):
                    k41 = perez.get("k41")[1]
                    if((epsilon >= perez.get("einf")[2]) & (epsilon >= perez.get("einf")[3])):
                        k41 = perez.get("k41")[3]
                        if((epsilon >= perez.get("einf")[3]) & (epsilon >= perez.get("einf")[4])):
                            k41 = perez.get("k41")[4]
                            if((epsilon >= perez.get("einf")[4]) & (epsilon >= perez.get("einf")[5])):
                                k41 = perez.get("k41")[5]
                                if((epsilon >= perez.get("einf")[5]) & (epsilon >= perez.get("einf")[6])):
                                    k41 = perez.get("k41")[6]
                                    if(epsilon>=perez.get("einf")[6]):
                                        k41 = perez.get("k41")[7]
            
            #k42
            k42 = 0.0
            if(epsilon == 0):
                k42 = 0.0
            elif((epsilon >= perez.get("einf")[0]) & (epsilon >= perez.get("einf")[1])):
                k42 = perez.get("k42")[0]
                if((epsilon >= perez.get("einf")[1]) & (epsilon >= perez.get("einf")[2])):
                    k42 = perez.get("k42")[1]
                    if((epsilon >= perez.get("einf")[2]) & (epsilon >= perez.get("einf")[3])):
                        k42 = perez.get("k42")[3]
                        if((epsilon >= perez.get("einf")[3]) & (epsilon >= perez.get("einf")[4])):
                            k42 = perez.get("k42")[4]
                            if((epsilon >= perez.get("einf")[4]) & (epsilon >= perez.get("einf")[5])):
                                k42 = perez.get("k42")[5]
                                if((epsilon >= perez.get("einf")[5]) & (epsilon >= perez.get("einf")[6])):
                                    k42 = perez.get("k42")[6]
                                    if(epsilon>=perez.get("einf")[6]):
                                        k42 = perez.get("k42")[7]
            
            #k43
            k43 = 0.0
            if(epsilon == 0):
                k43 = 0.0
            elif((epsilon >= perez.get("einf")[0]) & (epsilon >= perez.get("einf")[1])):
                k43 = perez.get("k43")[0]
                if((epsilon >= perez.get("einf")[1]) & (epsilon >= perez.get("einf")[2])):
                    k43 = perez.get("k43")[1]
                    if((epsilon >= perez.get("einf")[2]) & (epsilon >= perez.get("einf")[3])):
                        k43 = perez.get("k43")[3]
                        if((epsilon >= perez.get("einf")[3]) & (epsilon >= perez.get("einf")[4])):
                            k43 = perez.get("k43")[4]
                            if((epsilon >= perez.get("einf")[4]) & (epsilon >= perez.get("einf")[5])):
                                k43 = perez.get("k43")[5]
                                if((epsilon >= perez.get("einf")[5]) & (epsilon >= perez.get("einf")[6])):
                                    k43 = perez.get("k43")[6]
                                    if(epsilon>=perez.get("einf")[6]):
                                        k43 = perez.get("k43")[7]
            
            #k3
            k3 = k31+k32*delta+k33*qZsRad

            #k4
            k4 = k41+k42*delta+k43*qZsRad

            #Dc(a,b)
            dcab = d0*k3*maxi/qZs

            #Di(a,b)
            diab = d0*(0.5*(1+math.cos(inclinacionR))*(1-k3)+k4*math.sin(inclinacionR))

            #D(a,b)
            dab = dcab + diab
            sumaDab += dab
        
            #R(a,b)
            rab = 0.0
            if(type(coef) is Decimal):
                coef = float(coef)
            if(g0 > 0.0):
                rab = g0*coef*(1-math.cos(inclinacionR))/2
                #rab = coef
            sumaRab += rab
        
            #G(a,b) = Ghm(a,b)
            gab = bab+dab+rab
            sumaGab += gab
        

            #B(a,b)+Dc(a,b)
            babdcab = bab+dcab
            sumaTotal += babdcab
            #print('babdcab', babdcab)
            #print('delta', delta)
        resultado = {"sumD0":sumD0, "sumG0":sumG0, "sumBa_b":sumBa_b, "sumaDab":sumaDab, "sumaRab":sumaRab, "sumaGab":sumaGab, "sumaTotal":sumaTotal}
        return resultado


    def crear_matriz(m, n):
        print('hades vb')
        matriz = []
        print('hades')
        for i in range(n):
            matriz.append([])
            for j in range(m):
                matriz[i].append(0)
        print (matriz)
        return matriz                
#uelin1986@gmail.com