-- MariaDB dump 10.19  Distrib 10.11.4-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: solardb
-- ------------------------------------------------------
-- Server version	11.1.2-MariaDB-1:11.1.2+maria~ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `canton`
--

DROP TABLE IF EXISTS `canton`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `canton` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `estado` tinyint(1) DEFAULT NULL,
  `external_id` varchar(100) DEFAULT NULL,
  `id_provincia` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_provincia` (`id_provincia`),
  CONSTRAINT `canton_ibfk_1` FOREIGN KEY (`id_provincia`) REFERENCES `provincia` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=224 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `canton`
--

LOCK TABLES `canton` WRITE;
/*!40000 ALTER TABLE `canton` DISABLE KEYS */;
INSERT INTO `canton` VALUES
(1,'Loja',1,'3ea01885-e5a9-11ed-8f7d-b48c9d8e7c23',1),
(2,'Machala',1,'5f4245b5-e5a9-11ed-8f7d-b48c9d8e7c23',2),
(3,'Catamayo',1,'64520b0b-e5a9-11ed-8f7d-b48c9d8e7c23',1),
(4,'CUENCA',1,'9d25334b-73a9-11ee-a2ff-b48c9d8e7c23',9),
(5,'GIRÓN',1,'9d2663d5-73a9-11ee-a2ff-b48c9d8e7c23',9),
(6,'GUALACEO',1,'9d2690f2-73a9-11ee-a2ff-b48c9d8e7c23',9),
(7,'NABÓN',1,'9d26d01e-73a9-11ee-a2ff-b48c9d8e7c23',9),
(8,'PAUTE',1,'9d26ebcf-73a9-11ee-a2ff-b48c9d8e7c23',9),
(9,'PUCARA',1,'9d2709dd-73a9-11ee-a2ff-b48c9d8e7c23',9),
(10,'SAN FERNANDO',1,'9d272576-73a9-11ee-a2ff-b48c9d8e7c23',9),
(11,'SANTA ISABEL',1,'9d27424a-73a9-11ee-a2ff-b48c9d8e7c23',9),
(12,'SIGSIG',1,'9d275e7a-73a9-11ee-a2ff-b48c9d8e7c23',9),
(13,'OÑA',1,'9d277935-73a9-11ee-a2ff-b48c9d8e7c23',9),
(14,'CHORDELEG',1,'9d27935b-73a9-11ee-a2ff-b48c9d8e7c23',9),
(15,'EL PAN',1,'9d27ace8-73a9-11ee-a2ff-b48c9d8e7c23',9),
(16,'SEVILLA DE ORO',1,'9d27c8b9-73a9-11ee-a2ff-b48c9d8e7c23',9),
(17,'GUACHAPALA',1,'9d27e3fc-73a9-11ee-a2ff-b48c9d8e7c23',9),
(18,'CAMILO PONCE ENRÍQUEZ',1,'9d28047a-73a9-11ee-a2ff-b48c9d8e7c23',9),
(19,'GUARANDA',1,'9d282236-73a9-11ee-a2ff-b48c9d8e7c23',10),
(20,'CHILLANES',1,'9d285982-73a9-11ee-a2ff-b48c9d8e7c23',10),
(21,'CHIMBO',1,'9d2878eb-73a9-11ee-a2ff-b48c9d8e7c23',10),
(22,'ECHEANDÍA',1,'9d289549-73a9-11ee-a2ff-b48c9d8e7c23',10),
(23,'SAN MIGUEL',1,'9d28b148-73a9-11ee-a2ff-b48c9d8e7c23',10),
(24,'CALUMA',1,'9d28cb3a-73a9-11ee-a2ff-b48c9d8e7c23',10),
(25,'LAS NAVES',1,'9d28e588-73a9-11ee-a2ff-b48c9d8e7c23',10),
(26,'AZOGUES',1,'9d28ff1e-73a9-11ee-a2ff-b48c9d8e7c23',11),
(27,'BIBLIÁN',1,'9d291925-73a9-11ee-a2ff-b48c9d8e7c23',11),
(28,'CAÑAR',1,'9d2932d1-73a9-11ee-a2ff-b48c9d8e7c23',11),
(29,'LA TRONCAL',1,'9d294c6b-73a9-11ee-a2ff-b48c9d8e7c23',11),
(30,'EL TAMBO',1,'9d29689d-73a9-11ee-a2ff-b48c9d8e7c23',11),
(31,'DÉLEG',1,'9d2985a2-73a9-11ee-a2ff-b48c9d8e7c23',11),
(32,'SUSCAL',1,'9d29a0d4-73a9-11ee-a2ff-b48c9d8e7c23',11),
(33,'TULCÁN',1,'9d29d7a4-73a9-11ee-a2ff-b48c9d8e7c23',12),
(34,'BOLÍVAR',1,'9d29f6ca-73a9-11ee-a2ff-b48c9d8e7c23',12),
(35,'ESPEJO',1,'9d2a11c5-73a9-11ee-a2ff-b48c9d8e7c23',12),
(36,'MIRA',1,'9d2a2c70-73a9-11ee-a2ff-b48c9d8e7c23',12),
(37,'MONTÚFAR',1,'9d2a4a69-73a9-11ee-a2ff-b48c9d8e7c23',12),
(38,'SAN PEDRO DE HUACA',1,'9d2a673a-73a9-11ee-a2ff-b48c9d8e7c23',12),
(39,'LATACUNGA',1,'9d2a8391-73a9-11ee-a2ff-b48c9d8e7c23',13),
(40,'LA MANÁ',1,'9d2a9ff6-73a9-11ee-a2ff-b48c9d8e7c23',13),
(41,'PANGUA',1,'9d2abcdb-73a9-11ee-a2ff-b48c9d8e7c23',13),
(42,'PUJILI',1,'9d2ad9e2-73a9-11ee-a2ff-b48c9d8e7c23',13),
(43,'SALCEDO',1,'9d2af985-73a9-11ee-a2ff-b48c9d8e7c23',13),
(44,'SAQUISILÍ',1,'9d2b176c-73a9-11ee-a2ff-b48c9d8e7c23',13),
(45,'SIGCHOS',1,'9d2b36bc-73a9-11ee-a2ff-b48c9d8e7c23',13),
(46,'RIOBAMBA',1,'9d2b72ce-73a9-11ee-a2ff-b48c9d8e7c23',14),
(47,'ALAUSI',1,'9d2b90c3-73a9-11ee-a2ff-b48c9d8e7c23',14),
(48,'COLTA',1,'9d2bb145-73a9-11ee-a2ff-b48c9d8e7c23',14),
(49,'CHAMBO',1,'9d2bd3c2-73a9-11ee-a2ff-b48c9d8e7c23',14),
(50,'CHUNCHI',1,'9d2bfa91-73a9-11ee-a2ff-b48c9d8e7c23',14),
(51,'GUAMOTE',1,'9d2c23ae-73a9-11ee-a2ff-b48c9d8e7c23',14),
(52,'GUANO',1,'9d2c4353-73a9-11ee-a2ff-b48c9d8e7c23',14),
(53,'PALLATANGA',1,'9d2c5da1-73a9-11ee-a2ff-b48c9d8e7c23',14),
(54,'PENIPE',1,'9d2c7d76-73a9-11ee-a2ff-b48c9d8e7c23',14),
(55,'CUMANDÁ',1,'9d2c98af-73a9-11ee-a2ff-b48c9d8e7c23',14),
(56,'MACHALA',1,'9d2cba0b-73a9-11ee-a2ff-b48c9d8e7c23',2),
(57,'ARENILLAS',1,'9d2cd603-73a9-11ee-a2ff-b48c9d8e7c23',2),
(58,'ATAHUALPA',1,'9d2d01ac-73a9-11ee-a2ff-b48c9d8e7c23',2),
(59,'BALSAS',1,'9d2d3b64-73a9-11ee-a2ff-b48c9d8e7c23',2),
(60,'CHILLA',1,'9d2d5fbd-73a9-11ee-a2ff-b48c9d8e7c23',2),
(61,'EL GUABO',1,'9d2d7ceb-73a9-11ee-a2ff-b48c9d8e7c23',2),
(62,'HUAQUILLAS',1,'9d2d9ef3-73a9-11ee-a2ff-b48c9d8e7c23',2),
(63,'MARCABELÍ',1,'9d2dbdfd-73a9-11ee-a2ff-b48c9d8e7c23',2),
(64,'PASAJE',1,'9d2de2ba-73a9-11ee-a2ff-b48c9d8e7c23',2),
(65,'PIÑAS',1,'9d2dfe61-73a9-11ee-a2ff-b48c9d8e7c23',2),
(66,'PORTOVELO',1,'9d2e210e-73a9-11ee-a2ff-b48c9d8e7c23',2),
(67,'SANTA ROSA',1,'9d2e40da-73a9-11ee-a2ff-b48c9d8e7c23',2),
(68,'ZARUMA',1,'9d2e664c-73a9-11ee-a2ff-b48c9d8e7c23',2),
(69,'LAS LAJAS',1,'9d2e826b-73a9-11ee-a2ff-b48c9d8e7c23',2),
(70,'ESMERALDAS',1,'9d2ea53d-73a9-11ee-a2ff-b48c9d8e7c23',3),
(71,'ELOY ALFARO',1,'9d2ec285-73a9-11ee-a2ff-b48c9d8e7c23',3),
(72,'MUISNE',1,'9d2eff27-73a9-11ee-a2ff-b48c9d8e7c23',3),
(73,'QUININDÉ',1,'9d2f24b6-73a9-11ee-a2ff-b48c9d8e7c23',3),
(74,'SAN LORENZO',1,'9d2f418e-73a9-11ee-a2ff-b48c9d8e7c23',3),
(75,'ATACAMES',1,'9d2f64d5-73a9-11ee-a2ff-b48c9d8e7c23',3),
(76,'RIOVERDE',1,'9d2f7fa8-73a9-11ee-a2ff-b48c9d8e7c23',3),
(77,'LA CONCORDIA',1,'9d2fa007-73a9-11ee-a2ff-b48c9d8e7c23',3),
(78,'GUAYAQUIL',1,'9d2fbbe1-73a9-11ee-a2ff-b48c9d8e7c23',7),
(79,'ALFREDO BAQUERIZO MORENO (JUJÁN)',1,'9d2fe1b2-73a9-11ee-a2ff-b48c9d8e7c23',7),
(80,'BALAO',1,'9d300226-73a9-11ee-a2ff-b48c9d8e7c23',7),
(81,'BALZAR',1,'9d3026af-73a9-11ee-a2ff-b48c9d8e7c23',7),
(82,'COLIMES',1,'9d3044f2-73a9-11ee-a2ff-b48c9d8e7c23',7),
(83,'DAULE',1,'9d306c1f-73a9-11ee-a2ff-b48c9d8e7c23',7),
(84,'DURÁN',1,'9d308a99-73a9-11ee-a2ff-b48c9d8e7c23',7),
(85,'EL EMPALME',1,'9d30cbe1-73a9-11ee-a2ff-b48c9d8e7c23',7),
(86,'EL TRIUNFO',1,'9d30eda0-73a9-11ee-a2ff-b48c9d8e7c23',7),
(87,'MILAGRO',1,'9d312241-73a9-11ee-a2ff-b48c9d8e7c23',7),
(88,'NARANJAL',1,'9d31415b-73a9-11ee-a2ff-b48c9d8e7c23',7),
(89,'NARANJITO',1,'9d316759-73a9-11ee-a2ff-b48c9d8e7c23',7),
(90,'PALESTINA',1,'9d318814-73a9-11ee-a2ff-b48c9d8e7c23',7),
(91,'PEDRO CARBO',1,'9d31b297-73a9-11ee-a2ff-b48c9d8e7c23',7),
(92,'SAMBORONDÓN',1,'9d31d4a4-73a9-11ee-a2ff-b48c9d8e7c23',7),
(93,'SANTA LUCÍA',1,'9d31fb74-73a9-11ee-a2ff-b48c9d8e7c23',7),
(94,'SALITRE (URBINA JADO)',1,'9d321d14-73a9-11ee-a2ff-b48c9d8e7c23',7),
(95,'SAN JACINTO DE YAGUACHI',1,'9d32419d-73a9-11ee-a2ff-b48c9d8e7c23',7),
(96,'PLAYAS',1,'9d325e7b-73a9-11ee-a2ff-b48c9d8e7c23',7),
(97,'SIMÓN BOLÍVAR',1,'9d328257-73a9-11ee-a2ff-b48c9d8e7c23',7),
(98,'CORONEL MARCELINO MARIDUEÑA',1,'9d32c0a8-73a9-11ee-a2ff-b48c9d8e7c23',7),
(99,'LOMAS DE SARGENTILLO',1,'9d32e64b-73a9-11ee-a2ff-b48c9d8e7c23',7),
(100,'NOBOL',1,'9d330303-73a9-11ee-a2ff-b48c9d8e7c23',7),
(101,'GENERAL ANTONIO ELIZALDE',1,'9d332671-73a9-11ee-a2ff-b48c9d8e7c23',7),
(102,'ISIDRO AYORA',1,'9d3345fd-73a9-11ee-a2ff-b48c9d8e7c23',7),
(103,'IBARRA',1,'9d336937-73a9-11ee-a2ff-b48c9d8e7c23',15),
(104,'ANTONIO ANTE',1,'9d338453-73a9-11ee-a2ff-b48c9d8e7c23',15),
(105,'COTACACHI',1,'9d33a42a-73a9-11ee-a2ff-b48c9d8e7c23',15),
(106,'OTAVALO',1,'9d33c147-73a9-11ee-a2ff-b48c9d8e7c23',15),
(107,'PIMAMPIRO',1,'9d33e1eb-73a9-11ee-a2ff-b48c9d8e7c23',15),
(108,'SAN MIGUEL DE URCUQUÍ',1,'9d33fe0b-73a9-11ee-a2ff-b48c9d8e7c23',15),
(109,'LOJA',1,'9d341dea-73a9-11ee-a2ff-b48c9d8e7c23',1),
(110,'CALVAS',1,'9d343986-73a9-11ee-a2ff-b48c9d8e7c23',1),
(111,'CELICA',1,'9d347e53-73a9-11ee-a2ff-b48c9d8e7c23',1),
(112,'CHAGUARPAMBA',1,'9d349dcd-73a9-11ee-a2ff-b48c9d8e7c23',1),
(113,'ESPÍNDOLA',1,'9d34bf5a-73a9-11ee-a2ff-b48c9d8e7c23',1),
(114,'GONZANAMÁ',1,'9d34d97c-73a9-11ee-a2ff-b48c9d8e7c23',1),
(115,'MACARÁ',1,'9d34f9e2-73a9-11ee-a2ff-b48c9d8e7c23',1),
(116,'PALTAS',1,'9d35164c-73a9-11ee-a2ff-b48c9d8e7c23',1),
(117,'PUYANGO',1,'9d3537f8-73a9-11ee-a2ff-b48c9d8e7c23',1),
(118,'SARAGURO',1,'9d35525c-73a9-11ee-a2ff-b48c9d8e7c23',1),
(119,'SOZORANGA',1,'9d357323-73a9-11ee-a2ff-b48c9d8e7c23',1),
(120,'ZAPOTILLO',1,'9d358df8-73a9-11ee-a2ff-b48c9d8e7c23',1),
(121,'PINDAL',1,'9d35ad02-73a9-11ee-a2ff-b48c9d8e7c23',1),
(122,'QUILANGA',1,'9d35c820-73a9-11ee-a2ff-b48c9d8e7c23',1),
(123,'OLMEDO',1,'9d35e93e-73a9-11ee-a2ff-b48c9d8e7c23',1),
(124,'BABAHOYO',1,'9d361c58-73a9-11ee-a2ff-b48c9d8e7c23',5),
(125,'BABA',1,'9d364019-73a9-11ee-a2ff-b48c9d8e7c23',5),
(126,'MONTALVO',1,'9d365b80-73a9-11ee-a2ff-b48c9d8e7c23',5),
(127,'PUEBLOVIEJO',1,'9d367c54-73a9-11ee-a2ff-b48c9d8e7c23',5),
(128,'QUEVEDO',1,'9d36974d-73a9-11ee-a2ff-b48c9d8e7c23',5),
(129,'URDANETA',1,'9d36b718-73a9-11ee-a2ff-b48c9d8e7c23',5),
(130,'VENTANAS',1,'9d36d625-73a9-11ee-a2ff-b48c9d8e7c23',5),
(131,'VÍNCES',1,'9d36f039-73a9-11ee-a2ff-b48c9d8e7c23',5),
(132,'PALENQUE',1,'9d3709db-73a9-11ee-a2ff-b48c9d8e7c23',5),
(133,'BUENA FÉ',1,'9d372444-73a9-11ee-a2ff-b48c9d8e7c23',5),
(134,'VALENCIA',1,'9d373f2e-73a9-11ee-a2ff-b48c9d8e7c23',5),
(135,'MOCACHE',1,'9d375a52-73a9-11ee-a2ff-b48c9d8e7c23',5),
(136,'QUINSALOMA',1,'9d377410-73a9-11ee-a2ff-b48c9d8e7c23',5),
(137,'PORTOVIEJO',1,'9d378e1a-73a9-11ee-a2ff-b48c9d8e7c23',4),
(138,'BOLÍVAR',1,'9d37a849-73a9-11ee-a2ff-b48c9d8e7c23',4),
(139,'CHONE',1,'9d37c22e-73a9-11ee-a2ff-b48c9d8e7c23',4),
(140,'EL CARMEN',1,'9d37f09f-73a9-11ee-a2ff-b48c9d8e7c23',4),
(141,'FLAVIO ALFARO',1,'9d380bd8-73a9-11ee-a2ff-b48c9d8e7c23',4),
(142,'JIPIJAPA',1,'9d3826fe-73a9-11ee-a2ff-b48c9d8e7c23',4),
(143,'JUNÍN',1,'9d38418e-73a9-11ee-a2ff-b48c9d8e7c23',4),
(144,'MANTA',1,'9d385d55-73a9-11ee-a2ff-b48c9d8e7c23',4),
(145,'MONTECRISTI',1,'9d3877d0-73a9-11ee-a2ff-b48c9d8e7c23',4),
(146,'PAJÁN',1,'9d389245-73a9-11ee-a2ff-b48c9d8e7c23',4),
(147,'PICHINCHA',1,'9d38adf0-73a9-11ee-a2ff-b48c9d8e7c23',4),
(148,'ROCAFUERTE',1,'9d38c982-73a9-11ee-a2ff-b48c9d8e7c23',4),
(149,'SANTA ANA',1,'9d38e66b-73a9-11ee-a2ff-b48c9d8e7c23',4),
(150,'SUCRE',1,'9d3902e8-73a9-11ee-a2ff-b48c9d8e7c23',4),
(151,'TOSAGUA',1,'9d391f38-73a9-11ee-a2ff-b48c9d8e7c23',4),
(152,'24 DE MAYO',1,'9d3939ed-73a9-11ee-a2ff-b48c9d8e7c23',4),
(153,'PEDERNALES',1,'9d3954a8-73a9-11ee-a2ff-b48c9d8e7c23',4),
(154,'OLMEDO',1,'9d396e7c-73a9-11ee-a2ff-b48c9d8e7c23',4),
(155,'PUERTO LÓPEZ',1,'9d398a1d-73a9-11ee-a2ff-b48c9d8e7c23',4),
(156,'JAMA',1,'9d39a500-73a9-11ee-a2ff-b48c9d8e7c23',4),
(157,'JARAMIJÓ',1,'9d39be8f-73a9-11ee-a2ff-b48c9d8e7c23',4),
(158,'SAN VICENTE',1,'9d39d930-73a9-11ee-a2ff-b48c9d8e7c23',4),
(159,'MORONA',1,'9d39f58f-73a9-11ee-a2ff-b48c9d8e7c23',18),
(160,'GUALAQUIZA',1,'9d3a2c4d-73a9-11ee-a2ff-b48c9d8e7c23',18),
(161,'LIMÓN INDANZA',1,'9d3a482a-73a9-11ee-a2ff-b48c9d8e7c23',18),
(162,'PALORA',1,'9d3a6490-73a9-11ee-a2ff-b48c9d8e7c23',18),
(163,'SANTIAGO',1,'9d3a8300-73a9-11ee-a2ff-b48c9d8e7c23',18),
(164,'SUCÚA',1,'9d3a9e8d-73a9-11ee-a2ff-b48c9d8e7c23',18),
(165,'HUAMBOYA',1,'9d3ab910-73a9-11ee-a2ff-b48c9d8e7c23',18),
(166,'SAN JUAN BOSCO',1,'9d3ad3bb-73a9-11ee-a2ff-b48c9d8e7c23',18),
(167,'TAISHA',1,'9d3aeef3-73a9-11ee-a2ff-b48c9d8e7c23',18),
(168,'LOGROÑO',1,'9d3b0b60-73a9-11ee-a2ff-b48c9d8e7c23',18),
(169,'PABLO SEXTO',1,'9d3b2a6a-73a9-11ee-a2ff-b48c9d8e7c23',18),
(170,'TIWINTZA',1,'9d3b45f3-73a9-11ee-a2ff-b48c9d8e7c23',18),
(171,'TENA',1,'9d3b5f75-73a9-11ee-a2ff-b48c9d8e7c23',19),
(172,'ARCHIDONA',1,'9d3b793a-73a9-11ee-a2ff-b48c9d8e7c23',19),
(173,'EL CHACO',1,'9d3b93a9-73a9-11ee-a2ff-b48c9d8e7c23',19),
(174,'QUIJOS',1,'9d3bad30-73a9-11ee-a2ff-b48c9d8e7c23',19),
(175,'CARLOS JULIO AROSEMENA TOLA',1,'9d3bc7b2-73a9-11ee-a2ff-b48c9d8e7c23',19),
(176,'PASTAZA',1,'9d3be147-73a9-11ee-a2ff-b48c9d8e7c23',21),
(177,'MERA',1,'9d3bfdba-73a9-11ee-a2ff-b48c9d8e7c23',21),
(178,'SANTA CLARA',1,'9d3c1a2c-73a9-11ee-a2ff-b48c9d8e7c23',21),
(179,'ARAJUNO',1,'9d3c3400-73a9-11ee-a2ff-b48c9d8e7c23',21),
(180,'QUITO',1,'9d3c6592-73a9-11ee-a2ff-b48c9d8e7c23',16),
(181,'CAYAMBE',1,'9d3c7fe6-73a9-11ee-a2ff-b48c9d8e7c23',16),
(182,'MEJIA',1,'9d3c9a42-73a9-11ee-a2ff-b48c9d8e7c23',16),
(183,'PEDRO MONCAYO',1,'9d3cb5d0-73a9-11ee-a2ff-b48c9d8e7c23',16),
(184,'RUMIÑAHUI',1,'9d3ccf66-73a9-11ee-a2ff-b48c9d8e7c23',16),
(185,'SAN MIGUEL DE LOS BANCOS',1,'9d3cea1d-73a9-11ee-a2ff-b48c9d8e7c23',16),
(186,'PEDRO VICENTE MALDONADO',1,'9d3d0615-73a9-11ee-a2ff-b48c9d8e7c23',16),
(187,'PUERTO QUITO',1,'9d3d222c-73a9-11ee-a2ff-b48c9d8e7c23',16),
(188,'AMBATO',1,'9d3d3c5a-73a9-11ee-a2ff-b48c9d8e7c23',17),
(189,'BAÑOS DE AGUA SANTA',1,'9d3d569e-73a9-11ee-a2ff-b48c9d8e7c23',17),
(190,'CEVALLOS',1,'9d3d7020-73a9-11ee-a2ff-b48c9d8e7c23',17),
(191,'MOCHA',1,'9d3d89f5-73a9-11ee-a2ff-b48c9d8e7c23',17),
(192,'PATATE',1,'9d3da3cb-73a9-11ee-a2ff-b48c9d8e7c23',17),
(193,'QUERO',1,'9d3dbedb-73a9-11ee-a2ff-b48c9d8e7c23',17),
(194,'SAN PEDRO DE PELILEO',1,'9d3dd8fe-73a9-11ee-a2ff-b48c9d8e7c23',17),
(195,'SANTIAGO DE PÍLLARO',1,'9d3df540-73a9-11ee-a2ff-b48c9d8e7c23',17),
(196,'TISALEO',1,'9d3e1047-73a9-11ee-a2ff-b48c9d8e7c23',17),
(197,'ZAMORA',1,'9d3e29c8-73a9-11ee-a2ff-b48c9d8e7c23',23),
(198,'CHINCHIPE',1,'9d3e4886-73a9-11ee-a2ff-b48c9d8e7c23',23),
(199,'NANGARITZA',1,'9d3e6644-73a9-11ee-a2ff-b48c9d8e7c23',23),
(200,'YACUAMBI',1,'9d3e9b65-73a9-11ee-a2ff-b48c9d8e7c23',23),
(201,'YANTZAZA (YANZATZA)',1,'9d3ebd94-73a9-11ee-a2ff-b48c9d8e7c23',23),
(202,'EL PANGUI',1,'9d3edbe3-73a9-11ee-a2ff-b48c9d8e7c23',23),
(203,'CENTINELA DEL CÓNDOR',1,'9d3f8bf8-73a9-11ee-a2ff-b48c9d8e7c23',23),
(204,'PALANDA',1,'9d3fa904-73a9-11ee-a2ff-b48c9d8e7c23',23),
(205,'PAQUISHA',1,'9d3fc45e-73a9-11ee-a2ff-b48c9d8e7c23',23),
(206,'SAN CRISTÓBAL',1,'9d3fe122-73a9-11ee-a2ff-b48c9d8e7c23',24),
(207,'ISABELA',1,'9d3ffe32-73a9-11ee-a2ff-b48c9d8e7c23',24),
(208,'SANTA CRUZ',1,'9d401bf1-73a9-11ee-a2ff-b48c9d8e7c23',24),
(209,'LAGO AGRIO',1,'9d403942-73a9-11ee-a2ff-b48c9d8e7c23',22),
(210,'GONZALO PIZARRO',1,'9d407379-73a9-11ee-a2ff-b48c9d8e7c23',22),
(211,'PUTUMAYO',1,'9d408d8a-73a9-11ee-a2ff-b48c9d8e7c23',22),
(212,'SHUSHUFINDI',1,'9d40a7e4-73a9-11ee-a2ff-b48c9d8e7c23',22),
(213,'SUCUMBÍOS',1,'9d40c205-73a9-11ee-a2ff-b48c9d8e7c23',22),
(214,'CASCALES',1,'9d40dc7b-73a9-11ee-a2ff-b48c9d8e7c23',22),
(215,'CUYABENO',1,'9d40f699-73a9-11ee-a2ff-b48c9d8e7c23',22),
(216,'ORELLANA',1,'9d410fd7-73a9-11ee-a2ff-b48c9d8e7c23',20),
(217,'AGUARICO',1,'9d4129a1-73a9-11ee-a2ff-b48c9d8e7c23',20),
(218,'LA JOYA DE LOS SACHAS',1,'9d4143a4-73a9-11ee-a2ff-b48c9d8e7c23',20),
(219,'LORETO',1,'9d415ee6-73a9-11ee-a2ff-b48c9d8e7c23',20),
(220,'SANTO DOMINGO',1,'9d41798e-73a9-11ee-a2ff-b48c9d8e7c23',8),
(221,'SANTA ELENA',1,'9d419419-73a9-11ee-a2ff-b48c9d8e7c23',6),
(222,'LA LIBERTAD',1,'9d41adab-73a9-11ee-a2ff-b48c9d8e7c23',6),
(223,'SALINAS',1,'9d41c6f5-73a9-11ee-a2ff-b48c9d8e7c23',6);
/*!40000 ALTER TABLE `canton` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `censo_solar`
--

DROP TABLE IF EXISTS `censo_solar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `censo_solar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mes` enum('ENERO','FEBRERO','MARZO','ABRIL','MAYO','JUNIO','JULIO','AGOSTO','SEPTIEMBRE','OCTUBRE','NOVIEMBRE','DICIEMBRE') DEFAULT NULL,
  `irradiacion` double DEFAULT NULL,
  `external_id` varchar(100) DEFAULT NULL,
  `id_sitio` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_sitio` (`id_sitio`),
  CONSTRAINT `censo_solar_ibfk_1` FOREIGN KEY (`id_sitio`) REFERENCES `sitio` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `censo_solar`
--

LOCK TABLES `censo_solar` WRITE;
/*!40000 ALTER TABLE `censo_solar` DISABLE KEYS */;
INSERT INTO `censo_solar` VALUES
(1,'ENERO',4.06,'5369beb7-73b1-11ee-a2ff-b48c9d8e7c23',1),
(2,'FEBRERO',4.22,'536ac113-73b1-11ee-a2ff-b48c9d8e7c23',1),
(3,'MARZO',4.17,'536ae225-73b1-11ee-a2ff-b48c9d8e7c23',1),
(4,'ABRIL',4.06,'536b2013-73b1-11ee-a2ff-b48c9d8e7c23',1),
(5,'MAYO',4.28,'536bbcd4-73b1-11ee-a2ff-b48c9d8e7c23',1),
(6,'JUNIO',3.86,'536bf503-73b1-11ee-a2ff-b48c9d8e7c23',1),
(7,'JULIO',4.25,'536c2e08-73b1-11ee-a2ff-b48c9d8e7c23',1),
(8,'AGOSTO',4.33,'536c63e2-73b1-11ee-a2ff-b48c9d8e7c23',1),
(9,'SEPTIEMBRE',4.36,'536c9394-73b1-11ee-a2ff-b48c9d8e7c23',1),
(10,'OCTUBRE',4.69,'536cc52c-73b1-11ee-a2ff-b48c9d8e7c23',1),
(11,'NOVIEMBRE',4.89,'536cf4f1-73b1-11ee-a2ff-b48c9d8e7c23',1),
(12,'DICIEMBRE',4.61,'536d129d-73b1-11ee-a2ff-b48c9d8e7c23',1),
(25,'ENERO',3.53,'c67d2331-73b1-11ee-a2ff-b48c9d8e7c23',3),
(26,'FEBRERO',3.72,'c67d62f6-73b1-11ee-a2ff-b48c9d8e7c23',3),
(27,'MARZO',4.19,'c67d81cc-73b1-11ee-a2ff-b48c9d8e7c23',3),
(28,'ABRIL',4.14,'c67dcbe5-73b1-11ee-a2ff-b48c9d8e7c23',3),
(29,'MAYO',3.58,'c67deec5-73b1-11ee-a2ff-b48c9d8e7c23',3),
(30,'JUNIO',3.14,'c67e0aa4-73b1-11ee-a2ff-b48c9d8e7c23',3),
(31,'JULIO',3.22,'c67e280a-73b1-11ee-a2ff-b48c9d8e7c23',3),
(32,'AGOSTO',3.22,'c67e60ff-73b1-11ee-a2ff-b48c9d8e7c23',3),
(33,'SEPTIEMBRE',3.14,'c67e7bbb-73b1-11ee-a2ff-b48c9d8e7c23',3),
(34,'OCTUBRE',3.03,'c67e95c6-73b1-11ee-a2ff-b48c9d8e7c23',3),
(35,'NOVIEMBRE',3.11,'c67eaf99-73b1-11ee-a2ff-b48c9d8e7c23',3),
(36,'DICIEMBRE',3.44,'c7482837-73b1-11ee-a2ff-b48c9d8e7c23',3),
(37,'ENERO',4.42,'8ae12065-73b4-11ee-a2ff-b48c9d8e7c23',2),
(38,'FEBRERO',4.81,'8ae27e9f-73b4-11ee-a2ff-b48c9d8e7c23',2),
(39,'MARZO',5,'8ae33733-73b4-11ee-a2ff-b48c9d8e7c23',2),
(40,'ABRIL',4.56,'8ae3eefc-73b4-11ee-a2ff-b48c9d8e7c23',2),
(41,'MAYO',4.78,'8ae4396d-73b4-11ee-a2ff-b48c9d8e7c23',2),
(42,'JUNIO',4,'8ae45c00-73b4-11ee-a2ff-b48c9d8e7c23',2),
(43,'JULIO',3.72,'8ae47cb7-73b4-11ee-a2ff-b48c9d8e7c23',2),
(44,'AGOSTO',4.17,'8ae49905-73b4-11ee-a2ff-b48c9d8e7c23',2),
(45,'SEPTIEMBRE',3.78,'8ae4b359-73b4-11ee-a2ff-b48c9d8e7c23',2),
(46,'OCTUBRE',3.86,'8ae4cd84-73b4-11ee-a2ff-b48c9d8e7c23',2),
(47,'NOVIEMBRE',3.83,'8ae4e720-73b4-11ee-a2ff-b48c9d8e7c23',2),
(48,'DICIEMBRE',4.69,'8b86b77d-73b4-11ee-a2ff-b48c9d8e7c23',2);
/*!40000 ALTER TABLE `censo_solar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provincia`
--

DROP TABLE IF EXISTS `provincia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provincia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `estado` tinyint(1) DEFAULT NULL,
  `external_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provincia`
--

LOCK TABLES `provincia` WRITE;
/*!40000 ALTER TABLE `provincia` DISABLE KEYS */;
INSERT INTO `provincia` VALUES
(1,'Loja',1,'0e699fc0-e5a9-11ed-8f7d-b48c9d8e7c23'),
(2,'El oro',1,'291d09d6-e5a9-11ed-8f7d-b48c9d8e7c23'),
(3,'Esmeraldas',1,'21057f92-73a3-11ee-a2ff-b48c9d8e7c23'),
(4,'Manabí',1,'2105cdb2-73a3-11ee-a2ff-b48c9d8e7c23'),
(5,'Los Ríos',1,'21061ef3-73a3-11ee-a2ff-b48c9d8e7c23'),
(6,'Santa Elena',1,'21063d77-73a3-11ee-a2ff-b48c9d8e7c23'),
(7,'Guayas',1,'210657eb-73a3-11ee-a2ff-b48c9d8e7c23'),
(8,'Santo Domingo de los Tsáchilas',1,'210673b0-73a3-11ee-a2ff-b48c9d8e7c23'),
(9,'Azuay',1,'21068d94-73a3-11ee-a2ff-b48c9d8e7c23'),
(10,'Bolívar',1,'2106a79c-73a3-11ee-a2ff-b48c9d8e7c23'),
(11,'Cañar',1,'2106c2cf-73a3-11ee-a2ff-b48c9d8e7c23'),
(12,'Carchi',1,'2106ddb8-73a3-11ee-a2ff-b48c9d8e7c23'),
(13,'Cotopaxi',1,'2106f797-73a3-11ee-a2ff-b48c9d8e7c23'),
(14,'Chimborazo',1,'210711c2-73a3-11ee-a2ff-b48c9d8e7c23'),
(15,'Imbabura',1,'21072bbf-73a3-11ee-a2ff-b48c9d8e7c23'),
(16,'Pichincha',1,'2107458a-73a3-11ee-a2ff-b48c9d8e7c23'),
(17,'Tungurahua',1,'21075ee2-73a3-11ee-a2ff-b48c9d8e7c23'),
(18,'Morona Santiago',1,'210778a5-73a3-11ee-a2ff-b48c9d8e7c23'),
(19,'Napo',1,'2107abaf-73a3-11ee-a2ff-b48c9d8e7c23'),
(20,'Orellana',1,'2107c4ee-73a3-11ee-a2ff-b48c9d8e7c23'),
(21,'Pastaza',1,'2107dd67-73a3-11ee-a2ff-b48c9d8e7c23'),
(22,'Sucumbíos',1,'2107f610-73a3-11ee-a2ff-b48c9d8e7c23'),
(23,'Zamora Chinchipe',1,'21080f60-73a3-11ee-a2ff-b48c9d8e7c23'),
(24,'Galápagos',1,'21f3df53-73a3-11ee-a2ff-b48c9d8e7c23');
/*!40000 ALTER TABLE `provincia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitio`
--

DROP TABLE IF EXISTS `sitio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sitio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `ubicacion` varchar(255) DEFAULT NULL,
  `estado` tinyint(1) DEFAULT NULL,
  `external_id` varchar(100) DEFAULT NULL,
  `longitud` double DEFAULT NULL,
  `latitud` double DEFAULT NULL,
  `id_canton` int(11) NOT NULL,
  `promedio` double DEFAULT 0,
  `irradiacion` double DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `id_canton` (`id_canton`),
  CONSTRAINT `sitio_ibfk_1` FOREIGN KEY (`id_canton`) REFERENCES `canton` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitio`
--

LOCK TABLES `sitio` WRITE;
/*!40000 ALTER TABLE `sitio` DISABLE KEYS */;
INSERT INTO `sitio` VALUES
(1,'Loja','Centro de la ciudad',1,'d3384e7e-e5b0-11ed-8f7d-b48c9d8e7c23',-3.79,-4,1,4.3,1569),
(2,'Machala','Centro de la ciudad',1,'efc24388-e5b0-11ed-8f7d-b48c9d8e7c23',-3.6,-3.2,1,0,0),
(3,'Pasaje','SIN DEFINIR',1,'ab16b50c-73b1-11ee-a2ff-b48c9d8e7c23',-79.96,-3.226,64,3.45,1261);
/*!40000 ALTER TABLE `sitio` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-01 10:51:03
